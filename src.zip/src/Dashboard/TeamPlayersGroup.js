import React from 'react';
import DashboardNav from "../Dashboard/DashboardNav";
import classes from "./TeamPlayersGroup.module.css";


const PlayerDisplayCard = ({user_name}) => {
  
  return(
    <div className={classes.player_card}>
      <idv>
        <h3 className={classes.user_name}>{user_name}</h3>
      </idv>
    </div>
  );
}

const TeamPlayersGroup = () => {
  return (
    <div>
      <DashboardNav />
      <div className={classes.team_players_display_area}>
        <div className={classes.team_display_box}>
          <ul>
            <li>Arsenal</li>
            <li>Chelsea</li>
            <li>Liverpool</li>
            <li>Manchester City</li>
            <li>Manchester United</li>
          </ul>
        </div>

        <div className={classes.player_display_card_wrapper}>
            <PlayerDisplayCard user_name={"Hieran Tierny"} />
            <PlayerDisplayCard user_name="Declan Rice" />
            <PlayerDisplayCard user_name="Ben White" />
            <PlayerDisplayCard user_name="Gabriel Magahlaes" />
            <PlayerDisplayCard user_name="William Saliba" />
            <PlayerDisplayCard user_name="Jakub Kiwior" />
            <PlayerDisplayCard user_name="Rob Holding" />
            <PlayerDisplayCard user_name="Takehiro Tomiyasu" />
            <PlayerDisplayCard user_name="Olekzandhr Zincheko" />
            <PlayerDisplayCard user_name="Cedric Soares" />
            <PlayerDisplayCard user_name="Nuno Tavares" />
            <PlayerDisplayCard user_name="Aaron Ramsdale" />
            
            <PlayerDisplayCard user_name={"Gavi"}/>
            <PlayerDisplayCard user_name="Pedri"/>
            <PlayerDisplayCard user_name="Sergi Roberto" />
            <PlayerDisplayCard user_name="Frenkie De Jong" />
            <PlayerDisplayCard user_name="Ilkay Gundogan" />
            <PlayerDisplayCard user_name="Oriol Romeu" />
            <PlayerDisplayCard user_name="Ferran Torres" />
            <PlayerDisplayCard user_name="Robert Lewandowski" />
            <PlayerDisplayCard user_name="Ansu Fati" />
            <PlayerDisplayCard user_name="Raphina" />
            <PlayerDisplayCard user_name="Inaki Pena" />
            <PlayerDisplayCard user_name="Aaron Ramsdale" />

            <PlayerDisplayCard user_name={"Benoit Badiashille"} />
            <PlayerDisplayCard user_name="Thiago Silva" />
            <PlayerDisplayCard user_name="Trevor Cabaloah" />
            <PlayerDisplayCard user_name="Ben Chilwell" />
            <PlayerDisplayCard user_name="Recee James" />
            <PlayerDisplayCard user_name="Marc Cruella" />
            <PlayerDisplayCard user_name="Wesley FonFona" />
            <PlayerDisplayCard user_name="Levi Coilwill" />
            <PlayerDisplayCard user_name="Malang Scarr" />
            <PlayerDisplayCard user_name="Iaan Maatsen" />
            <PlayerDisplayCard user_name="Kepa" />

            <PlayerDisplayCard user_name={"Hieran Tierny"} />
            <PlayerDisplayCard user_name="Declan Rice" />
            <PlayerDisplayCard user_name="Ben White" />
            <PlayerDisplayCard user_name="Gabriel Magahlaes" />
            <PlayerDisplayCard user_name="William Saliba" />
            <PlayerDisplayCard user_name="Jakub Kiwior" />
            <PlayerDisplayCard user_name="Rob Holding" />
            <PlayerDisplayCard user_name="Takehiro Tomiyasu" />
            <PlayerDisplayCard user_name="Olekzandhr Zincheko" />
            <PlayerDisplayCard user_name="Cedric Soares" />
            <PlayerDisplayCard user_name="Nuno Tavares" />
            <PlayerDisplayCard user_name="Aaron Ramsdale" />

            <PlayerDisplayCard user_name={"Kyle Walker"} />
            <PlayerDisplayCard user_name="Ruben Dias" />
            <PlayerDisplayCard user_name="John Stones" />
            <PlayerDisplayCard user_name="Nathan Ake" />
            <PlayerDisplayCard user_name="Ayempric Laporte" />
            <PlayerDisplayCard user_name="Joao Cancelo" />
            <PlayerDisplayCard user_name="Kalvin Phillips" />
            <PlayerDisplayCard user_name="Jack Grealish" />
            <PlayerDisplayCard user_name="Rodri" />
            <PlayerDisplayCard user_name="Kevin De Bruyne" />
            <PlayerDisplayCard user_name="Nuno Tavares" />
            <PlayerDisplayCard user_name="Victor Lindelof" />
        </div>

      </div>
    </div>
  )
}

export default TeamPlayersGroup;