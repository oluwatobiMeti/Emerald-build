import React from 'react'
import "./aboutContent.css";
export default function AboutContent() {
  return (
    <div>
        <div class="imageHolder">
            <div class="TextHolder">
            <h3 className='textHeolder__header'>Get in touch</h3>
            <p class="text">To Get Informations About Football</p>
            </div>
        </div>
    </div>
  )
}
