import React from 'react';

function Matches({date}) {
  //  const {League} = premier;
  //  console.log(League);
   
  return (
    <div>
    <p>match</p>
      {/* <h1>{date}</h1>
      {League.map((match) => {console.log(match.matches.team1)
      <Match club1 = {match.matches.team1} club1Icon = {""} club2Icon = {""} club2 = {League.matches.team2} goal1 = {League.matches.score.ft[0]} goal2 = {League.matches.score.ft[0]}/>
       } )} */}
       
    </div>

  )
}

export default Matches
