import React from 'react'

function LineUp() {
  return (
    <p>lineup</p>
//     <div>
//       <table>
//   <tr className="leagueTable__header">
//     <th>{"club2"}</th>
//     <th>{"PLAYER"}</th>
//   </tr> 
//   {data.map(Clubs => <tr>
//     <td>{Clubs.player}</td>
//   </tr>)}
// </table>
// <table>
//   <tr className="leagueTable__header">
//     <th>{"club2"}</th>
//     <th>{"PLAYER"}</th>
//   </tr> 
//   {data.map(Clubs => <tr>
//     <td>{Clubs.player}</td>
//   </tr>)}
// </table>
//     </div>
  )
}

export default LineUp
