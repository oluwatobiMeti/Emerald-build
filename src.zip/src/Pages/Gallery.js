import react from "react";
import DashboardNav from "../Dashboard/DashboardNav";
import Footer from "../sections/Footer";

const Gallery = () => {
    return(
        <div>
           <DashboardNav/>
            
           <Footer/>
        </div>
    );
}

export default Gallery;